package com.acm.tallerfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TallerFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(TallerFinalApplication.class, args);
	}

}

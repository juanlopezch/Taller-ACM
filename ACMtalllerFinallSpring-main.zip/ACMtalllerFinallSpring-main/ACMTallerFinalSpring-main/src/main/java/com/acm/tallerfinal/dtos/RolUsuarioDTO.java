package com.acm.tallerfinal.dtos;

import lombok.Data;

@Data
public class RolUsuarioDTO {
    private Integer idRol;
    private String rol;
}